<?php

namespace Acme\AddressbookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeAddressbookBundle extends Bundle
{
}
